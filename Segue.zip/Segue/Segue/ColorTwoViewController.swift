//
//  ColorTwoViewController.swift
//  Segue
//
//  Created by iStudents on 3/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

protocol ColorTwoViewControllerDelegate{
    func myVCDidFinish(controller:ColorTwoViewController,text:String)
}

class ColorTwoViewController: UIViewController {
    
    var delegate: ColorTwoViewControllerDelegate? = nil
    var colorString = ""

    
    
    @IBOutlet weak var titleLable: UILabel!
    
    @IBOutlet weak var colorLable: UILabel!
    
    @IBAction func colorSelectionButton(sender: UIButton) {
          colorLable.text = sender.titleLabel!.text!
    }

    
    @IBAction func saveColor(sender: UIBarButtonItem) {
        if (delegate != nil){
        delegate!.myVCDidFinish(self, text: colorLable!.text!)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        colorLable.text = colorString
    }

}
