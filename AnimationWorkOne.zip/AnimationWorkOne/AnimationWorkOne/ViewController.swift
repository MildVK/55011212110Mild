//
//  ViewController.swift
//  AnimationWorkOne
//
//  Created by iStudents on 3/27/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var numberOfFishSlider: UISlider!
    
    @IBAction func animateButtonPressed(sender: AnyObject) {
      
            let numberOfFish = Int(self.numberOfFishSlider.value)
            
            for loopNumber in 0...numberOfFish {
                
                
                let duration : NSTimeInterval = 1.0
                let delay : NSTimeInterval = 0.0
                let options = UIViewAnimationOptions.CurveLinear
                
                
                let size : CGFloat = CGFloat( arc4random_uniform(75))+20
                let yPosition : CGFloat = CGFloat( arc4random_uniform(350))+20
                
                
                let fish = UIImageView()
                fish.image = UIImage(named:"pink-fish.png")
                fish.frame = CGRectMake(0, yPosition, size, size)
                self.view.addSubview(fish)
                
                
                UIView.animateWithDuration(duration, delay: delay, options: options, animations: {
                    
                    
                    fish.frame = CGRectMake(300-size, yPosition, size, size)
                    
                    }, completion: { animationFinished in
                        
                        fish.removeFromSuperview()
                        
                })
        }
    }

}

