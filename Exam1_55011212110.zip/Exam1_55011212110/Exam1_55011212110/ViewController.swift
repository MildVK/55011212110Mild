//
//  ViewController.swift
//  Exam1_55011212110
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
     
    }
    
    @IBOutlet weak var Subject: UITextField!
    
    @IBOutlet weak var Midterm: UITextField!
    
    @IBOutlet weak var Score1: UITextField!
    
    @IBOutlet weak var Point: UITextField!
    
    @IBOutlet weak var Score2: UITextField!
    
    @IBOutlet weak var Final: UITextField!
    
    @IBOutlet weak var Score3: UITextField!
    
    @IBOutlet weak var Sum: UITextView!
    
    

    @IBAction func SumTapped(sender: AnyObject) {
    }
    
    @IBAction func Total(sender: AnyObject) {
    }
    
    @IBAction func viewTapped(sender: AnyObject) {
        
    }
}
